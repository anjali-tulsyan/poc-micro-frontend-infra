export const increase = () => ({
  type: 'INCREASE'
});

export const decrease = () => ({
  type: 'DECREASE'
});
 

 export const setCounter = value => ({
 	type: 'SET_COUNTER',
 	data: value
 })
 