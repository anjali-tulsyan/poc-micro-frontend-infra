import React from 'react';
import Form from "./Form";
import Count from './Count';

const Dashboard = () => {



	return (
		<div>
			<Count />
			<Form />
		</div>
	)
}

export default Dashboard;