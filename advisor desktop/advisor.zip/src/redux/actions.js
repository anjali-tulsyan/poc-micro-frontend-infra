export const increase = text => ({
  type: 'INCREASE'
});

export const decrease = filter => ({
  type: 'DECREASE'
});
 
 